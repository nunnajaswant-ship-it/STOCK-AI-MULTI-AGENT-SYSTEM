import pandas as pd
import numpy as np

class TradingEngine:
    """Core trading simulation engine"""
    
    def __init__(self, agent, data, initial_capital):
        self.agent = agent
        self.data = data
        self.initial_capital = initial_capital
        self.cash = initial_capital
        self.holdings = 0
        self.history = []
    
    def run(self):
        """Execute trading simulation"""
        results = {
            'dates': [],
            'prices': [],
            'actions': [],
            'cash_history': [],
            'portfolio_values': [],
            'holdings_history': []
        }
        
        price_history = []
        
        for idx, row in self.data.iterrows():
            price = row['Close']
            date = row['Date']
            
            # Agent makes decision
            action = self.agent.decide(price, price_history, self.cash, self.holdings)
            
            # Execute action
            if action == 'BUY' and self.cash >= price:
                shares_to_buy = int(self.cash / price)
                if shares_to_buy > 0:
                    self.holdings += shares_to_buy
                    self.cash -= shares_to_buy * price
            
            elif action == 'SELL' and self.holdings > 0:
                self.cash += self.holdings * price
                self.holdings = 0
            
            # Record state
            portfolio_value = self.cash + (self.holdings * price)
            
            results['dates'].append(date)
            results['prices'].append(price)
            results['actions'].append(action)
            results['cash_history'].append(self.cash)
            results['portfolio_values'].append(portfolio_value)
            results['holdings_history'].append(self.holdings)
            
            price_history.append(price)
            self.agent.update_memory(price, action)
        
        return results
