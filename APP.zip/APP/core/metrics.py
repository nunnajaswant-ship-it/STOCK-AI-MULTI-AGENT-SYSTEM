import numpy as np

def calculate_metrics(results):
    """Calculate trading performance metrics"""
    
    portfolio_values = results['portfolio_values']
    initial_value = portfolio_values[0]
    final_value = portfolio_values[-1]
    
    # Total return
    total_return = ((final_value - initial_value) / initial_value) * 100
    
    # Calculate returns
    returns = np.diff(portfolio_values) / portfolio_values[:-1]
    
    # Volatility (annualized)
    volatility = np.std(returns) * np.sqrt(252) * 100
    
    # Sharpe ratio (assuming 0% risk-free rate)
    if volatility > 0:
        sharpe_ratio = (np.mean(returns) * 252) / (np.std(returns) * np.sqrt(252))
    else:
        sharpe_ratio = 0
    
    # Max drawdown
    peak = np.maximum.accumulate(portfolio_values)
    drawdown = (portfolio_values - peak) / peak * 100
    max_drawdown = np.min(drawdown)
    
    # Win rate
    actions = results['actions']
    trades = [i for i, a in enumerate(actions) if a in ['BUY', 'SELL']]
    
    if len(trades) > 1:
        winning_trades = 0
        for i in range(0, len(trades) - 1, 2):
            if i + 1 < len(trades):
                buy_idx = trades[i]
                sell_idx = trades[i + 1]
                if results['prices'][sell_idx] > results['prices'][buy_idx]:
                    winning_trades += 1
        
        win_rate = (winning_trades / (len(trades) // 2)) * 100 if len(trades) > 0 else 0
    else:
        win_rate = 0
    
    return {
        'total_return': total_return,
        'volatility': volatility,
        'sharpe_ratio': sharpe_ratio,
        'max_drawdown': max_drawdown,
        'win_rate': win_rate,
        'total_trades': len([a for a in actions if a != 'HOLD']),
        'final_value': final_value
    }
