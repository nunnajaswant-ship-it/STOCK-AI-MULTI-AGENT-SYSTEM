from agents.base import BaseAgent
import numpy as np

class UtilityBasedAgent(BaseAgent):
    """
    Utility-Based Agent: Balances risk vs reward
    Calculates utility score for each action
    """
    
    def __init__(self, algorithm, risk_aversion=0.5):
        super().__init__(algorithm)
        self.risk_aversion = risk_aversion
    
    def calculate_utility(self, expected_return, risk):
        """Utility = Expected Return - Risk Aversion * Risk"""
        return expected_return - (self.risk_aversion * risk)
    
    def decide(self, current_price, history, cash, holdings):
        if len(history) < 10:
            return 'HOLD'
        
        # Calculate expected return and risk
        returns = np.diff(history[-10:]) / history[-11:-1]
        expected_return = np.mean(returns)
        risk = np.std(returns)
        
        # Use algorithm to optimize utility
        action = self.algorithm.optimize(expected_return, current_price, cash, holdings)
        
        # Calculate utility for each action
        buy_utility = self.calculate_utility(expected_return, risk) if cash >= current_price else -999
        sell_utility = self.calculate_utility(-expected_return, risk) if holdings > 0 else -999
        hold_utility = 0
        
        utilities = {
            'BUY': buy_utility,
            'SELL': sell_utility,
            'HOLD': hold_utility
        }
        
        return max(utilities, key=utilities.get)
