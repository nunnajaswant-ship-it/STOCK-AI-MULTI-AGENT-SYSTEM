from agents.base import BaseAgent

class SimpleReflexAgent(BaseAgent):
    """
    Simple Reflex Agent: Reacts to immediate price change
    If price goes down → Buy
    If price goes up → Sell
    """
    
    def decide(self, current_price, history, cash, holdings):
        if len(history) < 2:
            return 'HOLD'
        
        prev_price = history[-1]
        price_change = current_price - prev_price
        
        # Use algorithm to optimize decision
        action = self.algorithm.optimize(price_change, current_price, cash, holdings)
        
        # Simple reflex logic
        if price_change < 0 and cash >= current_price:
            return 'BUY'
        elif price_change > 0 and holdings > 0:
            return 'SELL'
        else:
            return 'HOLD'
