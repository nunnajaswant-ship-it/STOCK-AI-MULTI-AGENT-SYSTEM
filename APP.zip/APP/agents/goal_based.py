from agents.base import BaseAgent

class GoalBasedAgent(BaseAgent):
    """
    Goal-Based Agent: Trades to reach target profit
    Has a profit goal and makes decisions to achieve it
    """
    
    def __init__(self, algorithm, target_return=0.15):
        super().__init__(algorithm)
        self.target_return = target_return
        self.entry_price = None
    
    def decide(self, current_price, history, cash, holdings):
        # Use algorithm to find path to goal
        action = self.algorithm.optimize(
            self.target_return, 
            current_price, 
            cash, 
            holdings
        )
        
        # If no position, look to buy
        if holdings == 0:
            if cash >= current_price:
                self.entry_price = current_price
                return 'BUY'
            return 'HOLD'
        
        # If have position, check if goal reached
        if self.entry_price:
            profit_pct = (current_price - self.entry_price) / self.entry_price
            
            if profit_pct >= self.target_return:
                self.entry_price = None
                return 'SELL'
            elif profit_pct < -0.05:  # Stop loss at -5%
                self.entry_price = None
                return 'SELL'
        
        return 'HOLD'
