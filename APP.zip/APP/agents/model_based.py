from agents.base import BaseAgent
import numpy as np

class ModelBasedAgent(BaseAgent):
    """
    Model-Based Agent: Uses short memory window to detect trends
    Analyzes last N prices to determine trend direction
    """
    
    def __init__(self, algorithm, window_size=5):
        super().__init__(algorithm)
        self.window_size = window_size
    
    def decide(self, current_price, history, cash, holdings):
        if len(history) < self.window_size:
            return 'HOLD'
        
        # Analyze trend over window
        window = history[-self.window_size:]
        trend = np.polyfit(range(len(window)), window, 1)[0]
        
        # Use algorithm to optimize
        action = self.algorithm.optimize(trend, current_price, cash, holdings)
        
        # Trend-based decision
        if trend < -0.5 and cash >= current_price:  # Downtrend - buy low
            return 'BUY'
        elif trend > 0.5 and holdings > 0:  # Uptrend - sell high
            return 'SELL'
        else:
            return 'HOLD'
