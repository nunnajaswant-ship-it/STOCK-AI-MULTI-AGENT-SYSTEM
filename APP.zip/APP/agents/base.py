from abc import ABC, abstractmethod

class BaseAgent(ABC):
    """Base class for all trading agents"""
    
    def __init__(self, algorithm):
        self.algorithm = algorithm
        self.memory = []
    
    @abstractmethod
    def decide(self, current_price, history, cash, holdings):
        """
        Make trading decision based on current state
        Returns: 'BUY', 'SELL', or 'HOLD'
        """
        pass
    
    def update_memory(self, price, action):
        """Store historical data"""
        self.memory.append({'price': price, 'action': action})
