class GreedyAlgorithm:
    """
    Greedy Best First: Always chooses immediate best option
    No long-term planning, just maximize current step
    """
    
    def optimize(self, signal, current_price, cash, holdings):
        # Always take the action that seems best right now
        if isinstance(signal, (int, float)):
            # Strong negative signal = buy opportunity
            if signal < -1 and cash >= current_price:
                return 'BUY'
            # Strong positive signal = sell opportunity
            elif signal > 1 and holdings > 0:
                return 'SELL'
            # Weak signals
            elif signal < 0 and cash >= current_price:
                return 'BUY'
            elif signal > 0 and holdings > 0:
                return 'SELL'
        
        return 'HOLD'
