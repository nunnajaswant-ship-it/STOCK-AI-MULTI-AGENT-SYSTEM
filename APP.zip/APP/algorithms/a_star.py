class AStarAlgorithm:
    """
    A* Search: Finds optimal path to maximize profit
    Uses heuristic to estimate future value
    """
    
    def optimize(self, signal, current_price, cash, holdings):
        # Heuristic: estimate future profit potential
        if isinstance(signal, (int, float)):
            # For trend/price change signals
            if signal < 0:  # Negative trend - opportunity to buy low
                cost = current_price
                potential_gain = abs(signal) * 10  # Heuristic multiplier
                score = potential_gain - cost
                return 'BUY' if score > 0 and cash >= current_price else 'HOLD'
            elif signal > 0 and holdings > 0:  # Positive trend - sell high
                return 'SELL'
        
        return 'HOLD'
