class HillClimbingAlgorithm:
    """
    Hill Climbing: Iteratively moves toward better profit
    Takes small steps to improve position
    """
    
    def __init__(self):
        self.last_action = 'HOLD'
        self.last_value = 0
    
    def optimize(self, signal, current_price, cash, holdings):
        current_value = cash + (holdings * current_price)
        
        # If last action improved value, continue similar strategy
        if current_value > self.last_value:
            self.last_value = current_value
            return self.last_action
        
        # Otherwise, try different action
        if isinstance(signal, (int, float)):
            if signal < 0 and cash >= current_price:
                self.last_action = 'BUY'
                return 'BUY'
            elif signal > 0 and holdings > 0:
                self.last_action = 'SELL'
                return 'SELL'
        
        self.last_action = 'HOLD'
        self.last_value = current_value
        return 'HOLD'
