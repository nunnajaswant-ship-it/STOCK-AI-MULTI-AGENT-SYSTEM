import streamlit as st
import pandas as pd
import plotly.graph_objects as go
from datetime import datetime, timedelta
import json
import os

from agents.simple_reflex import SimpleReflexAgent
from agents.model_based import ModelBasedAgent
from agents.goal_based import GoalBasedAgent
from agents.utility_based import UtilityBasedAgent
from algorithms.a_star import AStarAlgorithm
from algorithms.hill_climbing import HillClimbingAlgorithm
from algorithms.greedy import GreedyAlgorithm
from core.model import TradingEngine
from core.metrics import calculate_metrics
from data.loader import load_market_data
from live.live_feed import LiveFeed

st.set_page_config(page_title="AI Trading System", layout="wide", page_icon="📈")

# Initialize session state
if 'training_complete' not in st.session_state:
    st.session_state.training_complete = False
if 'training_results' not in st.session_state:
    st.session_state.training_results = None
if 'leaderboard' not in st.session_state:
    if os.path.exists('reports/leaderboard.json'):
        with open('reports/leaderboard.json', 'r') as f:
            st.session_state.leaderboard = json.load(f)
    else:
        st.session_state.leaderboard = []

# Header
st.title("🤖 AI-Based Intelligent Multi-Agent Trading System")
st.markdown("---")

# Sidebar Controls
with st.sidebar:
    st.header("⚙️ Configuration")
    
    agent_type = st.selectbox(
        "Agent Type",
        ["Simple Reflex", "Model-Based", "Goal-Based", "Utility-Based"],
        help="Choose AI agent decision-making strategy"
    )
    
    algorithm = st.selectbox(
        "Algorithm",
        ["A* Search", "Hill Climbing", "Greedy Best First"],
        help="Search algorithm for trade optimization"
    )
    
    mode = st.radio(
        "Mode",
        ["Training (Historical)", "Live Trading"],
        disabled=not st.session_state.training_complete if st.radio == "Live Trading" else False
    )
    
    market = st.selectbox(
        "Market Region",
        ["India", "USA", "Crypto"]
    )
    
    # Stock selection based on market
    stocks = {
        "India": ["RELIANCE.NS", "TCS.NS", "INFY.NS", "HDFCBANK.NS", "SBIN.NS"],
        "USA": ["AAPL", "MSFT", "AMZN", "TSLA", "NVDA"],
        "Crypto": ["BTC-USD", "ETH-USD", "BNB-USD", "SOL-USD", "XRP-USD"]
    }
    
    stock = st.selectbox("Select Asset", stocks[market])
    
    training_days = st.slider("Training Duration (days)", 30, 365, 90)
    initial_capital = st.number_input("Initial Capital ($)", 1000, 1000000, 10000, step=1000)
    
    st.markdown("---")
    
    run_training = st.button("🚀 Run Training", type="primary", use_container_width=True)
    run_live = st.button(
        "📡 Run Live Trading",
        type="secondary",
        disabled=not st.session_state.training_complete,
        use_container_width=True
    )

# Main content area
if run_training:
    with st.spinner(f"Training {agent_type} agent with {algorithm} on {stock}..."):
        # Load data
        data = load_market_data(stock, training_days)
        
        # Initialize agent
        agent_map = {
            "Simple Reflex": SimpleReflexAgent,
            "Model-Based": ModelBasedAgent,
            "Goal-Based": GoalBasedAgent,
            "Utility-Based": UtilityBasedAgent
        }
        
        algo_map = {
            "A* Search": AStarAlgorithm,
            "Hill Climbing": HillClimbingAlgorithm,
            "Greedy Best First": GreedyAlgorithm
        }
        
        agent = agent_map[agent_type](algo_map[algorithm]())
        
        # Run training
        engine = TradingEngine(agent, data, initial_capital)
        results = engine.run()
        
        # Calculate metrics
        metrics = calculate_metrics(results)
        
        # Store results
        st.session_state.training_complete = True
        st.session_state.training_results = {
            'results': results,
            'metrics': metrics,
            'config': {
                'agent': agent_type,
                'algorithm': algorithm,
                'stock': stock,
                'market': market,
                'days': training_days,
                'capital': initial_capital
            }
        }
        
        # Update leaderboard
        leaderboard_entry = {
            'timestamp': datetime.now().isoformat(),
            'agent': agent_type,
            'algorithm': algorithm,
            'stock': stock,
            'return': metrics['total_return'],
            'sharpe': metrics['sharpe_ratio'],
            'max_drawdown': metrics['max_drawdown']
        }
        st.session_state.leaderboard.append(leaderboard_entry)
        
        # Save leaderboard
        os.makedirs('reports', exist_ok=True)
        with open('reports/leaderboard.json', 'w') as f:
            json.dump(st.session_state.leaderboard, f, indent=2)
        
        st.success("✅ Training Complete!")

if run_live and st.session_state.training_complete:
    st.info("📡 Live trading mode activated. Fetching real-time data...")
    
    config = st.session_state.training_results['config']
    
    # Initialize live feed
    live_feed = LiveFeed(config['stock'])
    
    # Create placeholder for live updates
    live_placeholder = st.empty()
    
    with live_placeholder.container():
        st.warning("🔴 LIVE MODE - Real-time trading simulation running...")
        st.write(f"Monitoring: {config['stock']}")

# Display results
if st.session_state.training_results:
    results = st.session_state.training_results['results']
    metrics = st.session_state.training_results['metrics']
    config = st.session_state.training_results['config']
    
    st.markdown("---")
    st.header("📊 Training Results")
    
    # Metrics cards
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.metric("Total Return", f"{metrics['total_return']:.2f}%")
    with col2:
        st.metric("Sharpe Ratio", f"{metrics['sharpe_ratio']:.2f}")
    with col3:
        st.metric("Max Drawdown", f"{metrics['max_drawdown']:.2f}%")
    with col4:
        st.metric("Win Rate", f"{metrics['win_rate']:.1f}%")
    
    # Charts
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("📈 Price Movement & Trades")
        fig_price = go.Figure()
        
        # Price line
        fig_price.add_trace(go.Scatter(
            x=results['dates'],
            y=results['prices'],
            mode='lines',
            name='Price',
            line=dict(color='blue', width=2)
        ))
        
        # Buy markers
        buy_dates = [results['dates'][i] for i, action in enumerate(results['actions']) if action == 'BUY']
        buy_prices = [results['prices'][i] for i, action in enumerate(results['actions']) if action == 'BUY']
        fig_price.add_trace(go.Scatter(
            x=buy_dates,
            y=buy_prices,
            mode='markers',
            name='Buy',
            marker=dict(color='green', size=10, symbol='triangle-up')
        ))
        
        # Sell markers
        sell_dates = [results['dates'][i] for i, action in enumerate(results['actions']) if action == 'SELL']
        sell_prices = [results['prices'][i] for i, action in enumerate(results['actions']) if action == 'SELL']
        fig_price.add_trace(go.Scatter(
            x=sell_dates,
            y=sell_prices,
            mode='markers',
            name='Sell',
            marker=dict(color='red', size=10, symbol='triangle-down')
        ))
        
        fig_price.update_layout(height=400, xaxis_title="Date", yaxis_title="Price ($)")
        st.plotly_chart(fig_price, use_container_width=True)
    
    with col2:
        st.subheader("💰 Portfolio Value")
        fig_portfolio = go.Figure()
        
        fig_portfolio.add_trace(go.Scatter(
            x=results['dates'],
            y=results['portfolio_values'],
            mode='lines',
            name='Portfolio Value',
            line=dict(color='green', width=2),
            fill='tozeroy'
        ))
        
        fig_portfolio.update_layout(height=400, xaxis_title="Date", yaxis_title="Value ($)")
        st.plotly_chart(fig_portfolio, use_container_width=True)
    
    # Trade log
    st.subheader("📋 Trade Log")
    trade_df = pd.DataFrame({
        'Step': range(len(results['actions'])),
        'Date': results['dates'],
        'Action': results['actions'],
        'Price': results['prices'],
        'Cash': results['cash_history'],
        'Portfolio Value': results['portfolio_values']
    })
    st.dataframe(trade_df, use_container_width=True, height=300)

# Leaderboard
if st.session_state.leaderboard:
    st.markdown("---")
    st.header("🏆 Leaderboard")
    
    leaderboard_df = pd.DataFrame(st.session_state.leaderboard)
    leaderboard_df = leaderboard_df.sort_values('return', ascending=False).head(10)
    
    st.dataframe(
        leaderboard_df[['agent', 'algorithm', 'stock', 'return', 'sharpe', 'max_drawdown']],
        use_container_width=True
    )
