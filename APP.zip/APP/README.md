# 🤖 AI-Based Intelligent Multi-Agent Trading System

A modern AI-driven stock market trading system where different AI agents use decision-making algorithms to analyze price movements and execute trades.

## 🚀 Quick Start

```bash
# Install dependencies
pip install -r requirements.txt

# Run the app
streamlit run app.py
```

## 🎯 Features

- **4 AI Agent Types**: Simple Reflex, Model-Based, Goal-Based, Utility-Based
- **3 Search Algorithms**: A* Search, Hill Climbing, Greedy Best First
- **Real Market Data**: India, USA, and Crypto markets via yfinance
- **Training Mode**: Backtest on historical data
- **Live Trading**: Real-time simulation (unlocked after training)
- **Performance Metrics**: Returns, Sharpe ratio, drawdown, win rate
- **Interactive Charts**: Price movements with buy/sell markers
- **Leaderboard**: Compare agent performance

## 📊 How It Works

1. Select agent type and algorithm
2. Choose market and asset
3. Set training duration and capital
4. Run training to see performance
5. Unlock live mode for real-time trading

## 🛠 Tech Stack

- **Frontend**: Streamlit
- **Data**: yfinance, pandas, numpy
- **Visualization**: Plotly
- **Backend**: Python 3.8+
