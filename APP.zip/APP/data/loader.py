import yfinance as yf
from datetime import datetime, timedelta
import pandas as pd

def load_market_data(symbol, days):
    """Load historical market data using yfinance"""
    
    end_date = datetime.now()
    start_date = end_date - timedelta(days=days)
    
    try:
        # Download data
        ticker = yf.Ticker(symbol)
        data = ticker.history(start=start_date, end=end_date)
        
        if data.empty:
            raise ValueError(f"No data found for {symbol}")
        
        # Reset index to make Date a column
        data = data.reset_index()
        
        # Ensure we have required columns
        if 'Close' not in data.columns:
            raise ValueError(f"Missing 'Close' price data for {symbol}")
        
        return data[['Date', 'Open', 'High', 'Low', 'Close', 'Volume']]
    
    except Exception as e:
        # Fallback to synthetic data if API fails
        print(f"Warning: Could not fetch real data for {symbol}. Using synthetic data. Error: {e}")
        return generate_synthetic_data(days)

def generate_synthetic_data(days):
    """Generate synthetic price data for testing"""
    import numpy as np
    
    dates = pd.date_range(end=datetime.now(), periods=days, freq='D')
    
    # Generate random walk with trend
    returns = np.random.normal(0.001, 0.02, days)
    prices = 100 * np.exp(np.cumsum(returns))
    
    data = pd.DataFrame({
        'Date': dates,
        'Open': prices * (1 + np.random.uniform(-0.01, 0.01, days)),
        'High': prices * (1 + np.random.uniform(0, 0.02, days)),
        'Low': prices * (1 - np.random.uniform(0, 0.02, days)),
        'Close': prices,
        'Volume': np.random.randint(1000000, 10000000, days)
    })
    
    return data
