import yfinance as yf
import time
from datetime import datetime

class LiveFeed:
    """Real-time market data feed"""
    
    def __init__(self, symbol):
        self.symbol = symbol
        self.ticker = yf.Ticker(symbol)
    
    def get_current_price(self):
        """Fetch current market price"""
        try:
            data = self.ticker.history(period='1d', interval='1m')
            if not data.empty:
                return data['Close'].iloc[-1]
            return None
        except Exception as e:
            print(f"Error fetching live price: {e}")
            return None
    
    def stream(self, callback, interval=60):
        """Stream live prices with callback"""
        while True:
            price = self.get_current_price()
            if price:
                callback(price, datetime.now())
            time.sleep(interval)
